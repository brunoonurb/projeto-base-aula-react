
function Home() {
  return (
    <div className="App">
      HOME EXEMPLO
    </div>
  );
}

export { Home };
